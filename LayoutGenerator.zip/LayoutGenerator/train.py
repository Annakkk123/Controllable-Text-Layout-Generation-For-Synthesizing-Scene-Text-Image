import json
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
import torch.optim as optim
from torch.optim.lr_scheduler import StepLR
from dataloader import MyDataset
from model.layout_transformer import LayoutTransformer
from util import get_width, get_key_words, adjust_overlap_box, shrink_box, adjust_font_size, alphabet_dic
from tqdm import tqdm
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

if __name__ == "__main__":
    # 定义 JSON 文件的路径
    train_path = './dataset/train/'
    test_path = './dataset/test/'
    # 创建数据集实例
    train_dataset = MyDataset(train_path)
    test_dataset = MyDataset(test_path)

    # 创建数据加载器
    batch_size = 80
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

    model = LayoutTransformer(layer_number=4).to(device)
    # 定义优化器
    optimizer = optim.Adam(model.parameters(), lr=0.0002)
    # 定义学习率调度器
    scheduler = StepLR(optimizer, step_size=1, gamma=0.96)

    # 定义损失函数
    criterion = nn.L1Loss()

    # 模型训练
    max_num_epochs = 300
    
    for epoch in tqdm(range(1, max_num_epochs+1)):
        # train_stage
        model.train()
        running_loss = 0.0
        for batch in train_loader:
            char_embed = torch.squeeze(batch["char_embed"].to(device), dim=1)
            direction_embed = batch["direction_embed"].to(device) 
            segment_embed = batch["segment_embed"].to(device)
            width_list = batch["width_list"].to(device)
            boxes_gt = batch["boxes_gt"].to(device)
            boxes = batch["boxes"].to(device)
            boxes_length = batch["boxes_length"].to(device)
            mask = batch["mask"].to(device)
            curved_embed = batch["curved_embed"].to(device)
            
            padding = torch.zeros(boxes.shape[0], 1, 4).to(device)
            right_shifted_boxes = torch.cat([padding, boxes[:,0:-1,:]],1) # (batch, 20, 4)
            # inference
            return_boxes = torch.zeros(boxes_gt.shape[0], boxes_gt.shape[1], boxes_gt.shape[2]).to(device)
            for box_index in range(20):
                if box_index == 0:
                    encoder_embedding = None
                    
                output, encoder_embedding = model(char_embed, direction_embed, segment_embed, width_list, right_shifted_boxes, mask, curved_embed, train=True, encoder_embedding=encoder_embedding) 
                # output = torch.clamp(output, min=0, max=1) # (bs, 20, 4)
                # add overlap detection
                # output = adjust_overlap_box(output, box_index) # (bs, 20, 4)
                if box_index < 19:
                    right_shifted_boxes[:,box_index+1,:] = output[:,box_index,:]
                return_boxes[:,box_index,:] = output[:, box_index, :]
            
            loss = criterion(return_boxes, boxes_gt)

            # 反向传播和优化
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            running_loss += loss.item()

        epoch_loss = running_loss / len(train_loader)
        print(f'[train] Epoch [{epoch}/{max_num_epochs}], Loss: {epoch_loss}')
        # 调整学习率
        scheduler.step()

        # test_stage
        with torch.no_grad():
            model.eval()
            running_loss = 0.0
            for batch in test_loader:
                char_embed = torch.squeeze(batch["char_embed"].to(device), dim=1)
                direction_embed = batch["direction_embed"].to(device) 
                segment_embed = batch["segment_embed"].to(device)
                width_list = batch["width_list"].to(device)
                boxes_gt = batch["boxes_gt"].to(device)
                boxes = batch["boxes"].to(device)
                boxes_length = batch["boxes_length"].to(device)
                mask = batch["mask"].to(device)
                curved_embed = batch["curved_embed"].to(device)
                
                padding = torch.zeros(boxes.shape[0], 1, 4).to(device)
                right_shifted_boxes = torch.cat([padding, boxes[:,0:-1,:]],1) # (batch, 20, 4)
                # inference
                return_boxes = torch.zeros(boxes_gt.shape[0], boxes_gt.shape[1], boxes_gt.shape[2]).to(device)
                for box_index in range(20):
                    if box_index == 0:
                        encoder_embedding = None
                    output, encoder_embedding = model(char_embed, direction_embed, segment_embed, width_list, right_shifted_boxes, mask, curved_embed, train=True, encoder_embedding=encoder_embedding) 
                    # output = torch.clamp(output, min=0, max=1) # (bs, 20, 4)
                    # add overlap detection
                    # output = adjust_overlap_box(output, box_index) # (bs, 20, 4)
                    if box_index < 19:
                        right_shifted_boxes[:,box_index+1,:] = output[:,box_index,:]
                    return_boxes[:,box_index,:] = output[:, box_index, :]
                
                loss = criterion(return_boxes, boxes_gt)
                running_loss += loss.item()
            epoch_loss = running_loss / len(test_loader)
            print(f'[test] Epoch [{epoch}/{max_num_epochs}], Loss: {epoch_loss}', flush=True)
        # 模型保存
        if epoch % 5 == 0:
            torch.save(model.state_dict(), f'checkpoints/model_{epoch}.pth')
