import torch
import torch.nn as nn 
from transformers import BertTokenizer
from transformers import AutoTokenizer, AutoModelForMaskedLM
from transformers import logging
logging.set_verbosity_warning()
logging.set_verbosity_error()
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

class TextConditioner(nn.Module):
    
    def __init__(self):
        super(TextConditioner, self).__init__()
        self.transformer = AutoModelForMaskedLM.from_pretrained('model/bert-base-chinese')
        self.tokenizer = BertTokenizer.from_pretrained('model/bert-base-chinese')
        
        # fix
        self.transformer.eval()
        # 重新定义最后一层
        self.transformer.cls = torch.nn.Linear(768, 768)
        # 将二维tensor初始化为单位矩阵
        nn.init.eye_(self.transformer.cls.weight)
        for param in self.transformer.parameters():
            param.requires_grad = False
        
    def forward(self, prompt_list):
        batch_encoding = self.tokenizer(prompt_list,truncation=True, max_length=20, return_length=True, return_overflowing_tokens=False, padding="max_length", return_tensors="pt", add_special_tokens=False)
        text_embedding = self.transformer(batch_encoding["input_ids"].cuda())
        return text_embedding.logits, batch_encoding["input_ids"], batch_encoding["attention_mask"], batch_encoding["length"] # 1, 20, 768  /  1, 768


class LayoutTransformer(nn.Module): 
    
    def __init__(self, layer_number=2):
        super(LayoutTransformer, self).__init__()
        
        self.encoder_layer = nn.TransformerEncoderLayer(d_model=512, nhead=8)
        self.transformer = torch.nn.TransformerEncoder(
            self.encoder_layer, num_layers=layer_number 
        )
        
        self.decoder_layer = nn.TransformerDecoderLayer(d_model=512, nhead=8)
        self.decoder_transformer = torch.nn.TransformerDecoder(
            self.decoder_layer, num_layers=layer_number 
        )

        self.width_embedding = nn.Embedding(256,512)
        self.position_embedding = nn.Embedding(256,512)
        self.direction_embed = nn.Sequential(
            nn.Linear(2, 512),
            nn.ReLU(),
        )
        self.curved_embed = nn.Sequential(
            nn.Linear(2, 512),
            nn.ReLU(),
        )
        self.segment_embed = nn.Embedding(20,512)
        
        self.x_embedding = nn.Embedding(512,512)
        self.y_embedding = nn.Embedding(512,512)
        self.w_embedding = nn.Embedding(512,512)
        self.h_embedding = nn.Embedding(512,512)

        self.input_layer = nn.Sequential(
            nn.Linear(768, 512),
            nn.ReLU(),
            nn.Linear(512, 512),
        )

        self.output_layer = nn.Sequential(
            nn.Linear(512, 128),
            nn.ReLU(),
            nn.Linear(128, 4),
        )

    def forward(self, char_embed, direction_embed, segment_embed, width, right_shifted_boxes, enc_mask, curved_embed, train=False, encoder_embedding=None) :
        
        # detect whether the encoder_embedding is cached
        enc_mask = torch.squeeze(enc_mask, dim=1)
        enc_mask = (1 - enc_mask).bool()
        if encoder_embedding is None:
            # augmentation
            if train:
                width = width + torch.randint(-3, 3, (width.shape[0], width.shape[1])).to(device)

            x = self.input_layer(char_embed) # (bs, 20, 512) 

            width_embedding = self.width_embedding(torch.clamp(width, 0, 255).long()) # (bs, 20, 512)
            pe = torch.arange(20).to(device).unsqueeze(0)
            pe = pe.repeat(x.shape[0], 1)
            pe_embedding = self.position_embedding(pe) # (bs, 20, 512)    
            
            direction_embed = self.direction_embed(direction_embed)
            curved_embed = self.curved_embed(curved_embed)

            segment_embed = self.segment_embed(segment_embed)
            segment_embed = torch.squeeze(segment_embed, dim=2)

            total_embedding = x + width_embedding + pe_embedding + direction_embed + segment_embed + curved_embed # combine all the embeddings (1, 20, 512)    
            total_embedding = total_embedding.permute(1,0,2) # (20, bs, 512)
            encoder_embedding = self.transformer(total_embedding, src_key_padding_mask=enc_mask) # (20, bs, 512)    
      
        right_shifted_boxes_resize = (right_shifted_boxes * 512).long() # (bs, 20, 4)
        right_shifted_boxes_resize = torch.clamp(right_shifted_boxes_resize, 0, 511) # (bs, 20, 4)
        
        # decoder pe
        pe_decoder = torch.arange(20).to(device) # (20, )
        pe_embedding_decoder = self.position_embedding(pe_decoder).unsqueeze(0) # (bs, 20, 512)
        decoder_input = pe_embedding_decoder + self.x_embedding(right_shifted_boxes_resize[:,:,0]) + self.y_embedding(right_shifted_boxes_resize[:,:,1]) + self.w_embedding(right_shifted_boxes_resize[:,:,2]) + self.h_embedding(right_shifted_boxes_resize[:,:,3]) # (bs, 20, 512)
        decoder_input = decoder_input.permute(1,0,2) # (20, bs, 512)
        
        # generate triangular mask
        mask = nn.Transformer.generate_square_subsequent_mask(20) # (20, 20)
        mask = mask.to(device) # (20, 20)
        decoder_result = self.decoder_transformer(decoder_input, encoder_embedding, tgt_mask=mask, tgt_key_padding_mask=enc_mask) # (20, bs, 512)
        decoder_result = decoder_result.permute(1,0,2) # (bs, 20, 512)
        
        box_prediction = self.output_layer(decoder_result) # (bs, 20, 4)
        return box_prediction, encoder_embedding

# if __name__ == "__main__":
#     device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
#     model = TextConditioner().to(device)
#     text_embedding, batch_encoding = model(["abc", "你好"])
    