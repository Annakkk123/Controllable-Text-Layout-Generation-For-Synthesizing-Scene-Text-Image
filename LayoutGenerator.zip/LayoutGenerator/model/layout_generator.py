# ------------------------------------------
# TextDiffuser: Diffusion Models as Text Painters
# Paper Link: https://arxiv.org/abs/2305.10855
# Code Link: https://github.com/microsoft/unilm/tree/master/textdiffuser
# Copyright (c) Microsoft Corporation.
# This file aims to predict the layout of keywords in user prompts.
# ------------------------------------------
import jieba
import shutil
import json
import os
import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning)
import sys
sys.path.append(".")
import re
import numpy as np
import torch
import torch.nn as nn
from transformers import BertTokenizer
from transformers import CLIPTokenizer
from PIL import Image, ImageDraw, ImageFont
from util import get_width, get_key_words, adjust_overlap_box, shrink_box, adjust_font_size, alphabet_dic
from model.layout_transformer import LayoutTransformer, TextConditioner
from termcolor import colored
import argparse
from tqdm import tqdm


# import text encoder and tokenizer
text_encoder = TextConditioner().cuda().eval()
tokenizer = BertTokenizer.from_pretrained('model/bert-base-chinese')


def process_caption(font_path, caption):
    
    max_length = 20
    # caption_words = tokenizer([caption], truncation=True, max_length=max_length, return_length=True, return_overflowing_tokens=False, padding="max_length", return_tensors="pt", add_special_tokens=False)
    # caption_words_ids = caption_words['input_ids']
    # mask = caption_words["attention_mask"]

    char_embed, caption_words_ids, mask, length = text_encoder([caption])
    # length = caption_words['length']
    words = tokenizer.convert_ids_to_tokens(caption_words_ids.view(-1).tolist())
    words = [i.replace('</w>', '') for i in words]
    words_valid = words[:int(length)]

    # width_list =[]
    boxes = []
    for i in range(len(words_valid)):
        # width_list.append(get_width(font_path, words_valid[i]))
        boxes.append([0,0,0,0])

    boxes_length = len(boxes)
    while len(boxes) < max_length:
        # width_list.append(0)
        boxes.append([0,0,0,0])
    # width_list = torch.Tensor(width_list).long()

    return words_valid, boxes, [boxes_length], mask.tolist(), char_embed.tolist()

def labeling(path_list, data_dict):
    max_length = 20
    for path in tqdm(path_list):
        caption = ""
        name = path.split("/")[-1]
        with open(os.path.join(path, "text.txt"), "r") as f:
            caption = f.read().replace("\n", "")
        layout = np.load(os.path.join(path, "layout.npy"))
        direction = [0, 0]
        direction[layout[0]] = 1
        words, boxes, boxes_length, mask, char_embed = process_caption("", caption)
        direction_embed = []
        segment_embed = []
        for index, item in enumerate(layout[1:]):
            for i in range(item):
                direction_embed.append(direction)
                segment_embed.append([index])
        while len(direction_embed) < max_length:
            direction_embed.append([0, 0])
            segment_embed.append([0])

        width_list = []
        coords_seg = np.load(os.path.join(path, "coords_seg.npy"))
        for [x1, y1, x2, y2] in coords_seg:
            width = int(x2-x1)
            width_list.append(width)
        boxes_gt = coords_seg.tolist()
        data_dict[name] = {}
        data_dict[name]["caption"] = caption
        data_dict[name]["char_embed"] = char_embed
        data_dict[name]["direction_embed"] = direction_embed
        data_dict[name]["segment_embed"] = segment_embed
        data_dict[name]["width_list"] = width_list
        data_dict[name]["boxes_gt"] = boxes_gt
        data_dict[name]["boxes"] = boxes
        data_dict[name]["words"] = words
        data_dict[name]["boxes_length"] = boxes_length
        data_dict[name]["mask"] = mask


if __name__ == "__main__":
    
    train_dict = {}
    test_dict = {}
    base_dir1 = "./dataset/TextLogo3K"
    mode = "train"
    path_list = [os.path.join(base_dir1, mode, x) for x in os.listdir(os.path.join(base_dir1, mode))]
    labeling(path_list, train_dict)

    base_dir1 = "./dataset/layout_dataset"
    mode = "train"
    path_list = [os.path.join(base_dir1, mode, x) for x in os.listdir(os.path.join(base_dir1, mode))]
    labeling(path_list, train_dict)

    base_dir1 = "./dataset/TextLogo3K"
    mode = "test"
    path_list = [os.path.join(base_dir1, mode, x) for x in os.listdir(os.path.join(base_dir1, mode))]
    labeling(path_list, test_dict)

    with open("./dataset/train_data.json", 'w') as write_f:
	    write_f.write(json.dumps(train_dict, indent=4, ensure_ascii=False))

    with open("./dataset/test_data.json", 'w') as write_f:
	    write_f.write(json.dumps(test_dict, indent=4, ensure_ascii=False))
    
    


        
        
            

    

    