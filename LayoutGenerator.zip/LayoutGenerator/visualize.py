import matplotlib.pyplot as plt


train_loss = []
test_loss = []
# 假设有 train_loss 和 test_loss 数组，包含对应的损失值
with open("./train.log" ,"r") as f:
    for line in f.readlines():
        line = line.replace("\n", "").split(" ")
        mode = line[0]
        loss = float(line[-1])
        if mode == "[train]":
            train_loss.append(loss)
        else:
            test_loss.append(loss)

# 创建周期数数组
epochs = range(1, len(train_loss) + 1)

# 绘制训练损失折线
plt.plot(epochs, train_loss, 'r-', label='Train Loss')

# 绘制测试损失折线
plt.plot(epochs, test_loss, 'b-', label='Test Loss')

# 添加图例
plt.legend()

# 添加标题和轴标签
plt.title('Training and Test Loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')

# 保存图形为 JPG 格式
plt.savefig('loss_plot.jpg', dpi=300)
