import json
import os
from tqdm import tqdm
from model.layout_transformer import TextConditioner
from transformers import BertTokenizer
import torch
import numpy as np
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# import text encoder and tokenizer
text_encoder = TextConditioner().to(device).eval()
tokenizer = BertTokenizer.from_pretrained('model/bert-base-chinese')


def process_caption(font_path, caption):
    
    max_length = 20
    # caption_words = tokenizer([caption], truncation=True, max_length=max_length, return_length=True, return_overflowing_tokens=False, padding="max_length", return_tensors="pt", add_special_tokens=False)
    # caption_words_ids = caption_words['input_ids']
    # mask = caption_words["attention_mask"]

    char_embed, caption_words_ids, mask, length = text_encoder([caption])
    # length = caption_words['length']
    words = tokenizer.convert_ids_to_tokens(caption_words_ids.view(-1).tolist())
    words = [i.replace('</w>', '') for i in words]
    words_valid = words[:int(length)]

    # width_list =[]
    boxes = []
    for i in range(len(words_valid)):
        # width_list.append(get_width(font_path, words_valid[i]))
        boxes.append([0,0,0,0])

    boxes_length = len(boxes)
    while len(boxes) < max_length:
        # width_list.append(0)
        boxes.append([0,0,0,0])
    # width_list = torch.Tensor(width_list).long()

    return words_valid, boxes, [boxes_length], mask.tolist(), char_embed.tolist()

def labeling(path_list, mode):
    max_length = 20
    for path in tqdm(path_list):
        caption = ""
        name = path.split("/")[-1]
        with open(os.path.join(path, "text.txt"), "r") as f:
            caption = f.read().replace("\n", "")
        layout = np.load(os.path.join(path, "layout.npy"))
        direction = [0, 0]
        curved = [0, 0]
        if layout[0] < 2:
            direction[layout[0]] = 1
            curved[0] = 1
        else:
            direction[layout[0]-2] = 1
            curved[1] = 1
        words, boxes, boxes_length, mask, char_embed = process_caption("", caption)
        direction_embed = []
        segment_embed = []
        curved_embed = []
        for index, item in enumerate(layout[1:]):
            for i in range(item):
                direction_embed.append(direction)
                curved_embed.append(curved)
                segment_embed.append([index])
        while len(direction_embed) < max_length:
            direction_embed.append([0, 0])
            curved_embed.append([0, 0])
            segment_embed.append([0])

        width_list = []
        coords_seg = np.load(os.path.join(path, "coords_seg.npy"))
        for [x1, y1, x2, y2] in coords_seg:
            width = int(x2-x1)
            width_list.append(width)
        boxes_gt = coords_seg.tolist()
        boxes_gt = torch.FloatTensor(boxes_gt) / 128
        boxes_gt = boxes_gt.tolist()
        data_dict = {}
        data_dict["name"] = name
        data_dict["caption"] = caption
        data_dict["char_embed"] = char_embed
        data_dict["direction_embed"] = direction_embed
        data_dict["segment_embed"] = segment_embed
        data_dict["width_list"] = width_list
        data_dict["boxes_gt"] = boxes_gt
        data_dict["boxes"] = boxes
        data_dict["words"] = words
        data_dict["boxes_length"] = boxes_length
        data_dict["mask"] = mask
        data_dict["curved_embed"] = curved_embed
        with open(f"./dataset/{mode}/{name}.json", 'w') as write_f:
	        write_f.write(json.dumps(data_dict, indent=2, ensure_ascii=False))
        

def labeling_2(path_list, mode):
    max_length = 20
    for path in tqdm(path_list):
        caption = ""
        name = "curved_" + path.split("/")[-1].replace(".box", "")
        layout = None
        boxes_gt = []
        with open(path, "r") as f:
            lines = f.readlines()
            tmp = lines[-1].replace("\n", "").split(" ")
            layout = [int(x) for x in tmp]
            length = sum(layout[1:])
            for line in lines[:length]:
                line = line.replace("\n", "").split(" ")
                caption += line[0]
                boxes_gt.append([int(line[1]), int(line[2]), int(line[3]), int(line[4])])
        
        while(len(boxes_gt)< max_length):
            boxes_gt.append([0, 0, 1, 1])
        
        direction = [0, 0]
        curved = [0, 0]
        if layout[0] < 2:
            direction[layout[0]] = 1
            curved[0] = 1
        else:
            direction[layout[0]-2] = 1
            curved[1] = 1
        words, boxes, boxes_length, mask, char_embed = process_caption("", caption)
        direction_embed = []
        segment_embed = []
        curved_embed = []
        for index, item in enumerate(layout[1:]):
            for i in range(item):
                direction_embed.append(direction)
                curved_embed.append(curved)
                segment_embed.append([index])
        while len(direction_embed) < max_length:
            direction_embed.append([0, 0])
            curved_embed.append([0, 0])
            segment_embed.append([0])

        width_list = []
        for [x1, y1, x2, y2] in boxes_gt:
            width = int(x2-x1)
            width_list.append(width)
        
        boxes_gt = torch.FloatTensor(boxes_gt) / 256
        boxes_gt = boxes_gt.tolist()
        data_dict = {}
        data_dict["name"] = name
        data_dict["caption"] = caption
        data_dict["char_embed"] = char_embed
        data_dict["direction_embed"] = direction_embed
        data_dict["segment_embed"] = segment_embed
        data_dict["width_list"] = width_list
        data_dict["boxes_gt"] = boxes_gt
        data_dict["boxes"] = boxes
        data_dict["words"] = words
        data_dict["boxes_length"] = boxes_length
        data_dict["mask"] = mask
        data_dict["curved_embed"] = curved_embed
        with open(f"./dataset/{mode}/{name}.json", 'w') as write_f:
	        write_f.write(json.dumps(data_dict, indent=2, ensure_ascii=False))
        

if __name__ == "__main__":

    base_dir1 = "./dataset/TextLogo3K"
    mode = "train"
    path_list = [os.path.join(base_dir1, mode, x) for x in os.listdir(os.path.join(base_dir1, mode))]
    labeling(path_list, mode)

    base_dir1 = "./dataset/TextLogo3K"
    mode = "test"
    path_list = [os.path.join(base_dir1, mode, x) for x in os.listdir(os.path.join(base_dir1, mode))]
    labeling(path_list, mode)

    base_dir1 = "./dataset/layout_dataset"
    mode = "train"
    path_list = [os.path.join(base_dir1, mode, x) for x in os.listdir(os.path.join(base_dir1, mode))]
    labeling(path_list, mode)

    base_dir = "./dataset/curved"
    mode = "train"
    path_list = [os.path.join(base_dir, x) for x in os.listdir(base_dir)]
    labeling_2(path_list, mode)