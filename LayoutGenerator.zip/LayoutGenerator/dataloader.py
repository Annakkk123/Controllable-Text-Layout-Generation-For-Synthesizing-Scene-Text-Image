import json
import torch
import os
from torch.utils.data import Dataset, DataLoader

class MyDataset(Dataset):
    def __init__(self, file_dir):
        self.root = file_dir
        self.name = os.listdir(file_dir)

    def __len__(self):
        return len(self.name)

    def __getitem__(self, idx):
        name = self.name[idx]
        data_dict = None
        with open(os.path.join(self.root, name), "r") as f:
            data_dict = json.loads(f.read())
        # 在这里对样本字典进行处理
        processed_sample = {}
        processed_sample["char_embed"] = torch.FloatTensor(data_dict["char_embed"])
        processed_sample["direction_embed"] = torch.FloatTensor(data_dict["direction_embed"])
        processed_sample["segment_embed"] = torch.LongTensor(data_dict["segment_embed"])
        processed_sample["width_list"] = torch.LongTensor(data_dict["width_list"])
        processed_sample["boxes_gt"] = torch.FloatTensor(data_dict["boxes_gt"])
        processed_sample["boxes"] = torch.FloatTensor(data_dict["boxes"])
        processed_sample["boxes_length"] = torch.LongTensor(data_dict["boxes_length"])
        processed_sample["mask"] = torch.LongTensor(data_dict["mask"])
        processed_sample["curved_embed"] = torch.FloatTensor(data_dict["curved_embed"])

        return processed_sample
