import json
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from dataloader import MyDataset
from util import get_width, get_key_words, adjust_overlap_box, shrink_box, adjust_font_size, alphabet_dic
import jieba
import shutil
import os
import sys
sys.path.append(".")
import re
import numpy as np
from transformers import BertTokenizer
from PIL import Image, ImageDraw, ImageFont
from model.layout_transformer import LayoutTransformer, TextConditioner
from termcolor import colored
import argparse
from tqdm import tqdm
import random
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# import text encoder and tokenizer
text_encoder = TextConditioner().to(device).eval()
tokenizer = BertTokenizer.from_pretrained('model/bert-base-chinese')

from transformers import logging
logging.set_verbosity_warning()
logging.set_verbosity_error()

# import layout transformer
epoch = 200
folder_path = f"./results/{epoch}"
# 检查文件夹是否存在
if not os.path.exists(folder_path):
    # 如果文件夹不存在，则创建文件夹
    os.makedirs(folder_path)

model = LayoutTransformer(layer_number=4).to(device)
model.load_state_dict(torch.load(f'checkpoints/model_{epoch}.pth'))
max_length = 20

def process_caption(font_path, caption):
    
    char_embed, caption_words_ids, mask, length = text_encoder([caption])
    words = tokenizer.convert_ids_to_tokens(caption_words_ids.view(-1).tolist())
    words = [i.replace('</w>', '') for i in words]
    words_valid = words[:int(length)]

    width_list =[]
    boxes = []
    for i in range(len(words_valid)):
        width_list.append(get_width(font_path, words_valid[i]))
        boxes.append([0,0,0,0])

    boxes_length = len(boxes)
    while len(boxes) < max_length:
        width_list.append(0)
        boxes.append([0,0,0,0])

    return words_valid, boxes, [boxes_length], mask.tolist(), char_embed.tolist(), width_list


def test_data(font_path, caption, direction, layout=None):
    words_valid, boxes, boxes_length, mask, char_embed, width = process_caption(font_path, caption)
    # layout
    curved = [0, 0]
    direction_ = [0, 0]
    if layout is None:
        layout = [0]*len(boxes)
        if direction < 2:
            layout[0] = direction
            curved[0] = 1
            direction_[layout[0]] = 1
        else:
            layout[0] = direction
            curved[1] = 1
            direction_[layout[0]-2] = 1
        text_list = " ".join(jieba.cut(caption)).split()
        for i, text in enumerate(text_list):
            layout[i+1] = len(text)
    else:
        direction = layout[0]
        curved = [0, 0]
        if direction < 2:
            curved[0] = 1
            direction_[layout[0]] = 1
        else:
            curved[1] = 1
            direction_[layout[0]-2] = 1
    print("layout=", layout)
    print("caption=", caption)
    direction_embed = []
    segment_embed = []
    curved_embed = []

    for index, item in enumerate(layout[1:]):
        for i in range(item):
            direction_embed.append(direction_)
            curved_embed.append(curved)
            segment_embed.append([index])
    while len(direction_embed) < max_length:
        direction_embed.append([0, 0])
        segment_embed.append([0])
        curved_embed.append([0, 0])
    
    return torch.FloatTensor(char_embed),\
    torch.FloatTensor(direction_embed), \
    torch.LongTensor(segment_embed), \
    torch.LongTensor(width), \
    torch.FloatTensor(boxes), \
    torch.LongTensor(boxes_length), \
    torch.LongTensor(mask),\
    torch.FloatTensor(curved_embed), \
    words_valid


def adjust_font_size_1(font_path, width, height, draw, text):    
    size_start = height
    while True:
        try:
            font = ImageFont.truetype(font_path, size_start)
            text_width, _ = draw.textsize(text, font=font)
        except:
            print("text=", text)
            print("font=", font)
            print("size_start=", size_start)
            exit()
        if text_width >= width:
            size_start = size_start - 1
        else:
            return size_start
            

def get_img_and_mask(return_boxes, words_valid, font_path):
    # print the location of words_valid
    print(f'index\tkeyword\tx_min\ty_min\tx_max\ty_max')
    for index, keyword in enumerate(words_valid):
        x_min = int(return_boxes[index][0] * 512)
        y_min = int(return_boxes[index][1] * 512)
        x_max = int(return_boxes[index][2] * 512)
        y_max = int(return_boxes[index][3] * 512)
        print(f'{index}\t{keyword}\t{x_min}\t{y_min}\t{x_max}\t{y_max}')
    
    
    # paint the layout
    render_image = Image.new('RGB', (512, 512), (255, 255, 255))
    draw = ImageDraw.Draw(render_image)
    segmentation_mask = Image.new("L", (512,512), 0)
    segmentation_mask_draw = ImageDraw.Draw(segmentation_mask)

    for index, box in enumerate(return_boxes):
        box = [int(i*512) for i in box]
        xmin, ymin, xmax, ymax = box
        
        width = xmax - xmin
        height = ymax - ymin
        text = words_valid[index]

        font_size = adjust_font_size_1(font_path, width, height, draw, text)
        font = ImageFont.truetype(font_path, font_size)

        # draw.rectangle([xmin, ymin, xmax,ymax], outline=(255,0,0))
        draw.text((xmin, ymin), text, font=font, fill=(0, 0, 0))
            
        # boxes = []
        # for i, char in enumerate(text):
            
        #     # paint character-level segmentation masks
        #     # https://github.com/python-pillow/Pillow/issues/3921
        #     bottom_1 = font.getsize(text[i])[1]
        #     right, bottom_2 = font.getsize(text[:i+1])
        #     bottom = bottom_1 if bottom_1 < bottom_2 else bottom_2
        #     width, height = font.getmask(char).size
        #     right += xmin
        #     bottom += ymin
        #     top = bottom - height
        #     left = right - width
            
        #     char_box = (left, top, right, bottom)
        #     boxes.append(char_box)
            
        #     char_index = alphabet_dic[char]
        #     segmentation_mask_draw.rectangle(shrink_box(char_box, scale_factor = 0.9), fill=char_index)
    
    # print(f'{colored("[√]", "green")} Layout is successfully generated')
    return render_image


def test(font_path, caption, direction, layout=None):
    char_embed, direction_embed, segment_embed, width, boxes, boxes_length, mask, curved_embed, words_valid = test_data(font_path, caption, direction, layout)

    # cuda
    char_embed = char_embed.to(device)
    direction_embed = torch.unsqueeze(direction_embed.to(device), dim=0) 
    segment_embed = torch.unsqueeze(segment_embed.to(device), dim=0) 
    width = torch.unsqueeze(width.to(device), dim=0) 
    boxes = torch.unsqueeze(boxes.to(device), dim=0) 
    boxes_length = torch.unsqueeze(boxes_length.to(device), dim=0) 
    mask = mask.to(device)
    curved_embed = curved_embed.to(device)

    padding = torch.zeros(boxes.shape[0], 1, 4).to(device)
    right_shifted_boxes = torch.cat([padding, boxes[:,0:-1,:]],1) # (batch, 20, 4)
    # inference
    return_boxes = []
    with torch.no_grad():
        for box_index in range(boxes_length[0]):
            if box_index == 0:
                encoder_embedding = None
            output, encoder_embedding = model(char_embed, direction_embed, segment_embed, width, right_shifted_boxes, mask, curved_embed, train=False, encoder_embedding=encoder_embedding) 
            output = torch.clamp(output, min=0, max=1) # (bs, 20, 4)
            # add overlap detection
            output = adjust_overlap_box(output, box_index) # (bs, 20, 4)
            if box_index < boxes_length[0]-1:
                right_shifted_boxes[:,box_index+1,:] = output[:,box_index,:]
            xmin, ymin, xmax, ymax = output[0, box_index, :].tolist()
            return_boxes.append([xmin, ymin, xmax, ymax])
    
    render_image = get_img_and_mask(return_boxes, words_valid, font_path)
    render_image.save(f"{folder_path}/{caption}_{direction}.jpg", "JPEG")

def split_integer(n, num_parts):
    # 生成 num_parts-1 个随机数
    parts = random.sample(range(1, n), num_parts-1)
    # 将随机数排序并添加首尾两个边界值
    parts = sorted(parts + [0, n])
    # 计算每个部分的差值
    parts_diff = [parts[i+1] - parts[i] for i in range(num_parts)]
    return parts_diff

def layout_fun(direction, caption):
    layout = [0]*20
    layout[0] = direction
    total_len = len(caption)
    if direction >= 2:
        layout[1] = total_len
        return layout
    parts_diff = split_integer(total_len, total_len//3)
    for index, _ in enumerate(parts_diff):
        layout[index+1] = parts_diff[index]
    return layout


if __name__ == "__main__":
    font_path = "./ttfs/方正楷体简体.ttf"
    caption = "明天天气下午中雪"
    direction = 0
    layout = layout_fun(direction, caption)
    test(font_path, caption, direction, layout)
    
    direction = 1 
    layout = layout_fun(direction, caption)
    test(font_path, caption, direction, layout)

    direction = 2 
    layout = layout_fun(direction, caption)
    test(font_path, caption, direction, layout)

    direction = 3 
    layout = layout_fun(direction, caption)
    test(font_path, caption, direction, layout)
    
    pass
